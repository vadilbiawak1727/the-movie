import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'movie.dart';

class HttpHelper {
  final String _apiKey = "32ac6a92e68f0273bd800d909fb726ad";
  final String _baseUrl = "https://api.themoviedb.org";

  Future<List?> getMoviesByCategory() async {
    var url = Uri.parse(_baseUrl + '/3/movie/now_playing?api_key=' + _apiKey);

    http.Response result = await http.get(url);
    if (result.statusCode == HttpStatus.ok) {
      final jsonResponse = json.decode(result.body);
      final moviesMap = jsonResponse['results'];
      List movies = moviesMap.map((i) => Movie.fromJson(i)).toList();
      return movies;
    } else {
      return null;
    }
  }

  searchMovies(String query) {}

  getPopularMovies() {}

  getNowPlayingMovies() {}

  getTopRatedMovies() {}

  getUpcomingMovies() {}

  getLatestMovies() {}
}