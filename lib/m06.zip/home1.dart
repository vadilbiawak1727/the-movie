import 'package:flutter/material.dart';
import 'Detail.dart';
import 'HttpHelper.dart';
import 'movie.dart';
import 'ComingSoon.dart'; // Tambahkan import ComingSoon.dart

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  HttpHelper? helper;
  List<Movie>? movies;
  List<Movie>? filteredMovies;
  final String iconBase = 'https://image.tmdb.org/t/p/w92/';
  final String defaultImage =
      "https://images.freeimages.com/images/large-previews/Seb/movie-clapboard-1184339.jpg";
  String selectedCategory = 'Latest';

  @override
  void initState() {
    super.initState();
    helper = HttpHelper();
    _fetchMovies(selectedCategory);
  }

  Future<void> _fetchMovies(String category) async {
    List<Movie>? fetchedMovies;
    switch (category) {
      case 'Now Playing':
        fetchedMovies = await helper?.getNowPlayingMovies();
        break;
      case 'Popular':
        fetchedMovies = await helper?.getPopularMovies();
        break;
      case 'Top Rated':
        fetchedMovies = await helper?.getTopRatedMovies();
        break;
      case 'Upcoming':
        fetchedMovies = await helper?.getUpcomingMovies();
        break;
      case 'Latest':
        // Jika kategori adalah 'Latest', navigasikan ke halaman ComingSoon
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ComingSoon()),
        );
        return; // Tidak perlu melanjutkan eksekusi kode setelah navigasi.
      default:
        fetchedMovies = await helper?.getLatestMovies();
        break;
    }
    if (fetchedMovies != null) {
      setState(() {
        movies = fetchedMovies?.cast<Movie>();
        filteredMovies = movies;
      });
    }
  }

  void _filterMovies(String query) {
    setState(() {
      filteredMovies = movies
          ?.where((movie) =>
              movie.title.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    NetworkImage image;
    return Scaffold(
      appBar: AppBar(
        title: Text('Movies'),
        backgroundColor: Color.fromARGB(255, 110, 110, 110),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onChanged: (query) {
                _filterMovies(query);
              },
              decoration: InputDecoration(
                labelText: 'Search Movies',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: DropdownButton<String>(
              value: selectedCategory,
              items: <String>[
                'Latest',
                'Now Playing',
                'Popular',
                'Top Rated',
                'Upcoming',
              ].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedCategory = newValue!;
                  _fetchMovies(selectedCategory);
                });
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: (filteredMovies?.length == null) ? 0 : filteredMovies?.length,
              itemBuilder: (BuildContext context, int position) {
                if (filteredMovies![position].posterPath != null) {
                  image = NetworkImage(iconBase + filteredMovies![position].posterPath!);
                } else {
                  image = NetworkImage(defaultImage);
                }
                return Card(
                  color: Color.fromARGB(255, 27, 196, 145),
                  elevation: 2.0,
                  child: ListTile(
                    onTap: () {
                      MaterialPageRoute route = MaterialPageRoute(
                        builder: (_) => DetailScreen(filteredMovies![position]),
                      );
                      Navigator.push(context, route);
                    },
                    leading: CircleAvatar(
                      backgroundImage: image,
                    ),
                    title: Text(filteredMovies![position].title),
                    subtitle: Text(
                      "Released : " +
                          filteredMovies![position].releaseDate +
                          " - Vote" +
                          filteredMovies![position].voteAverage.toString(),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
